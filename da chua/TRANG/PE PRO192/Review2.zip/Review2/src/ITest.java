/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author Admin
 */
public interface ITest {
    // Cac thuoc tinh duoc khai bao trong interface thi se la dang PUBLIC, STATIC, FINAL
    int XYZ = 100;
    
    // Phuong thuc chac chan phai truu tuong
    void output();
    void f1();
    void f2();
}
