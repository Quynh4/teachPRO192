
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class Review2 {
    // Abstraction: tinh truu tuong
    // Tinh truu tuong la ban tao ra 
    // 1 class / interface ma truu tuong 
    // de che giau nhung chi tiet cai dat ben trong
    
    // VD: khi rut tien ta su dung cay rut tien, khi lai xe oto

    // Polymorphism: tinh da hinh
    // The hien qua
    // - Override method (ghi de phuong thuc)
    // La sua doi phuong thuc cua lop cha theo y mong muon
    
    // - Overload method (nap chong phuong thuc)
    // Cho phep dinh nghia nhieu phuong thuc cung ten nhau trong 1 class

    public static void main(String[] args) {
       // Array (mang tinh) vs ArrayList(mang dong)
        List<Integer> a = new ArrayList<>();
        
        a.add(1);
        a.add(2);
        a.add(10);
        a.add(-5);
        System.out.println(a);
        
        Collections.swap(a, 0, 2);
        System.out.println(a);
    }
    
}
