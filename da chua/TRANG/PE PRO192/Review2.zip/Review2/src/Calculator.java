/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class Calculator {
    public int add(int a, int b) {
        return a + b;
    }
    
    public double add(double a, double b) {
        return a + b;
    }
    
    public int add(int a, int b, int c) {
        return a + b + c;
    }
    
    // NAP CHONG THE HIEN QUA SO LUONG THAM SO, KIEU TRA VE, KIEU THAM SO
    
    public static void main(String[] args) {
        Calculator c = new Calculator();
        System.out.println(c.add(4.5, 6));
    }
}
