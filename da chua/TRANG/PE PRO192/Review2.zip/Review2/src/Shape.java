/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
abstract public class Shape {
    // Lop con co the la: Circle, Triangle, Rectangle
    
    // Lop truu tuong thi khong the duoc khoi tao    
    // Lop truu tuong CO THE co cac phuong thuc truu tuong hoac khong
    // -> KHONG HOAN TOAN DAT 100% TINH TRUU TUONG
    // NEU MUON DAT DUOC TINH TRUU TUONG 100% THI SU DUNG INTERFACE

    String color;
    
    // Phuong thuc truu tuong la phuong thuc khong co phan than
    abstract double getArea();
    abstract double getPerimeter();
    
    public void output() {
        System.out.println("THIS IS SHAPE CLASS");
    }
    
    // Khi lop con ke thua lop truu tuong thi bat buoc 
    // phai override tat ca cac phuong thuc truu tuong tu lop cha
    
    // LOP TRUU TUONG CUNG CO THE CO CONSTRUCTOR NHU CAC LOP KHAC

    public Shape() {
    }

    public Shape(String color) {
        this.color = color;
    }
    
}
