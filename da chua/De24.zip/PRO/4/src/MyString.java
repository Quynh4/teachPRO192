import java.util.*;

public class MyString implements IString {
  public int f1(String str) {
    String[] words = str.split("\\s+");
    int count = 0;

    for (String word : words) {
      if (hasTwoConsonants(word.toLowerCase())) {
        count++;
      }
    }

    return count;
  }

  public String f2(String str) {
    str = str.toLowerCase();
    Map<Character, Integer> charCount = new HashMap<>();

    for (char ch : str.toCharArray()) {
      if (Character.isLetter(ch)) {
        charCount.put(ch, charCount.getOrDefault(ch, 0) + 1);
      }
    }

    List<Character> duplicateChars = new ArrayList<>();
    for (Map.Entry<Character, Integer> entry : charCount.entrySet()) {
      if (entry.getValue() > 1) {
        duplicateChars.add(entry.getKey());
      }
    }

    if (duplicateChars.isEmpty()) {
      return "NO";
    }

    Collections.sort(duplicateChars, Collections.reverseOrder());

    StringBuilder sb = new StringBuilder();
    for (char ch : duplicateChars) {
      sb.append(ch);
    }

    return sb.toString();
  }

  private boolean hasTwoConsonants(String word) {
    int consonantCount = 0;
    for (char ch : word.toCharArray()) {
      if (isConsonant(ch)) {
        consonantCount++;
        if (consonantCount >= 2) {
          return true;
        }
      }
    }
    return false;
  }

  private boolean isConsonant(char ch) {
    ch = Character.toLowerCase(ch);
    return ch >= 'b' && ch <= 'z' && ch != 'a' && ch != 'e' && ch != 'i' && ch != 'o' && ch != 'u';
  }
}